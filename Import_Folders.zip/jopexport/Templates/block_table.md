# Table Template

# 4x4
| Header | Header | Header | Header |
|--------|--------|--------|--------|
| A      | B      | C      | D      |
| E      | F      | G      | H      |
| I      | J      | K      | L      |


# 3x3
| Header | Header | Header |
|--------|--------|--------|
| A      | B      | C      |
| D      | E      | F      |

# 2x2
| Header | Header |
|--------|--------|
| A      | B      |
| C      | D      |