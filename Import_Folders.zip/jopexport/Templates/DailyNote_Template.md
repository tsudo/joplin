---
template_title: {{ date }} » Journal
template_tags: Journal

---
# {{date}} » Journal
Date: {{#custom_datetime}}[]MMM[ ]D[ ]YYYY[]{{/custom_datetime}} | Time stamp: {{#custom_datetime}}[]YYYY[-]MM[-]DD[ ]HH[:]mm[]{{/custom_datetime}}


## Priorities
1. One
2. Two
3. Three

## Braindump
Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat


## Action items
- [ ] Action Item 1
- [ ] Action Item 2
- [ ] Action Item 3


🏷️ Tags: #journal