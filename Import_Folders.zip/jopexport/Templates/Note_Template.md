---
template_title: {{ date }} » Note
template_tags: note

---
# {{date}} » Note
Date: {{#custom_datetime}}[]MMM[ ]D[ ]YYYY[]{{/custom_datetime}} | Time stamp: {{#custom_datetime}}[]YYYY[-]MM[-]DD[ ]HH[:]mm[]{{/custom_datetime}}

## 📝Notes
Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. 

## ✅Action Items
- [ ] Item 1
- [ ] Item 2
- [ ] Item 3

## 🔑Summary / Key Takeaway(s)
Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. 


🏷️ Tags: #note